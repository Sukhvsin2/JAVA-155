class Math {

	//computes the sum of two values
	public static float add( float first, float second ) {
		
		//INSERT YOUR CODE
	}
	
	//computes the sum of array
	public static float add( float[] arr ) {
		
		//INSERT YOUR CODE
	}
	
	//computes the mulpication of two values
	public static float multiply( float first, float second ) {
		
		//INSERT YOUR CODE
	}
	
	//computes the mulpication of array
	public static float multiply( float[] arr ) {
		
		//INSERT YOUR CODE
	}
}